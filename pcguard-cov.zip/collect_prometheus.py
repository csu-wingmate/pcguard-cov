#!/usr/bin/python3

import sys
import time
import os

edge_cnt_file = sys.argv[1]
out_file = sys.argv[2]
fuzzer = sys.argv[3]
protocol = sys.argv[4]
i = sys.argv[5]

if os.path.exists(out_file):
    os.remove(out_file)

while True:
    try:
        with open(edge_cnt_file, 'rb') as f:
            edge_cnt = int.from_bytes(f.read(4), "little")
        
        with open(out_file, "w") as f:
            f.write(f'branch_coverage_{fuzzer}_{protocol}_{i}{{job="branch-cov"}} {edge_cnt}\n')
            print(f"Updated edge_cnt: {edge_cnt}")
    except Exception as e:
        print(f"An error occurred: {e}")
    
    time.sleep(1)

